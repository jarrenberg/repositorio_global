package com.betfair.esa.client.protocol;

/** Created by mulveyj on 07/07/2016. */
public enum ConnectionStatus {
    STOPPED,
    CONNECTED,
    AUTHENTICATED,
    SUBSCRIBED,
    DISCONNECTED,
}
