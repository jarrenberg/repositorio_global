package com.betfair.esa.client.auth;

/** Created by mulveyj on 08/07/2016. */
public class InvalidCredentialException extends Exception {
    public InvalidCredentialException(String message) {
        super(message);
    }
}
