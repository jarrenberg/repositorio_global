
# KeyLineDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kl** | [**List&lt;KeyLineSelection&gt;**](KeyLineSelection.md) |  |  [optional]



