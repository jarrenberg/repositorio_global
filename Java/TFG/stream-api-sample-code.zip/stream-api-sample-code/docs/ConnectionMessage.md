
# ConnectionMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connectionId** | **String** | The connection id |  [optional]



