
# RequestMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**op** | **String** | The operation type |  [optional]
**id** | **Integer** | Client generated unique id to link request with response (like json rpc) |  [optional]



