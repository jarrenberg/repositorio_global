
# MarketDataFilter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ladderLevels** | **Integer** |  |  [optional]
**fields** | [**List&lt;FieldsEnum&gt;**](#List&lt;FieldsEnum&gt;) |  |  [optional]


<a name="List<FieldsEnum>"></a>
## Enum: List&lt;FieldsEnum&gt;
Name | Value
---- | -----
EX_BEST_OFFERS_DISP | &quot;EX_BEST_OFFERS_DISP&quot;
EX_BEST_OFFERS | &quot;EX_BEST_OFFERS&quot;
EX_ALL_OFFERS | &quot;EX_ALL_OFFERS&quot;
EX_TRADED | &quot;EX_TRADED&quot;
EX_TRADED_VOL | &quot;EX_TRADED_VOL&quot;
EX_LTP | &quot;EX_LTP&quot;
EX_MARKET_DEF | &quot;EX_MARKET_DEF&quot;
SP_TRADED | &quot;SP_TRADED&quot;
SP_PROJECTED | &quot;SP_PROJECTED&quot;



