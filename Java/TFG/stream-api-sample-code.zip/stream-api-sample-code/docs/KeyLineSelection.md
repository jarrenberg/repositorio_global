
# KeyLineSelection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**hc** | **Double** |  |  [optional]



