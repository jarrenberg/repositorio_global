
# PriceLadderDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
CLASSIC | &quot;CLASSIC&quot;
FINEST | &quot;FINEST&quot;
LINE_RANGE | &quot;LINE_RANGE&quot;



