
# AuthenticationMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**session** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]



