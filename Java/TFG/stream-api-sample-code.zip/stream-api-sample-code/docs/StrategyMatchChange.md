
# StrategyMatchChange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mb** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) | Matched Backs - matched amounts by distinct matched price on the Back side for this strategy |  [optional]
**ml** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) | Matched Lays - matched amounts by distinct matched price on the Lay side for this strategy |  [optional]



