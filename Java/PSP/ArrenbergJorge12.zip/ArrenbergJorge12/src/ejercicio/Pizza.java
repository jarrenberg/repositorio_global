package ejercicio;

public class Pizza {

}
